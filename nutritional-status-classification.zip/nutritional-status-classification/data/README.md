# Data folder

Repo ini tidak menyertakan dataset mentah.

Letakkan file CSV dataset kamu di:
- `data/data_balita.csv`

Lalu pastikan notebook membaca path tersebut (atau sesuaikan path di notebook).

Tips:
- Kalau dataset kamu besar, jangan di-commit ke GitHub. Simpan sebagai file lokal / Google Drive, atau pakai Git LFS.
